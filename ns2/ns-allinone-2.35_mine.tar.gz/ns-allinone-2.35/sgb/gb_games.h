/*1:*/
#line 13 "gb_games.w"

extern Graph*games();

/*:1*//*5:*/
#line 140 "gb_games.w"

#define ap u.I 
#define upi v.I
#define abbr x.S
#define nickname y.S
#define conference z.S
#define HOME 1
#define NEUTRAL 2
#define AWAY 3
#define venue a.I
#define date b.I

/*:5*/
