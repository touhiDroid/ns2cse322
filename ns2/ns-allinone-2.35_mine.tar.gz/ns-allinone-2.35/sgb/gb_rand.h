/*1:*/
#line 26 "gb_rand.w"

#define random_graph r_graph

#define random_bigraph r_bigraph
#define random_lengths r_lengths
extern Graph*random_graph();
extern Graph*random_bigraph();
extern long random_lengths();

/*:1*/
