/*1:*/
#line 46 "gb_save.w"

extern long save_graph();
extern Graph*restore_graph();

/*:1*/
