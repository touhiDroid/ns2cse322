/*1:*/
#line 19 "gb_lisa.w"

#define plane_lisa p_lisa
extern long*lisa();
extern Graph*plane_lisa();
extern Graph*bi_lisa();

/*:1*//*3:*/
#line 121 "gb_lisa.w"

#define smile  m0= 94,m1= 110,n0= 97,n1= 129 
#define eyes  m0= 61,m1= 80,n0= 91,n1= 140 
extern char lisa_id[];

/*:3*//*25:*/
#line 431 "gb_lisa.w"

#define pixel_value  x.I 
#define first_pixel  y.I
#define last_pixel  z.I
#define matrix_rows  uu.I
#define matrix_cols  vv.I

/*:25*/
