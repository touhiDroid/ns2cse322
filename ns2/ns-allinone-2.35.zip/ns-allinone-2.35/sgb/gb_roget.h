/*1:*/
#line 13 "gb_roget.w"

extern Graph*roget();

/*:1*//*12:*/
#line 187 "gb_roget.w"

#define cat_no  u.I


/*:12*/
